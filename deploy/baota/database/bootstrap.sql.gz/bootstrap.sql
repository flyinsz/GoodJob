-- MySQL dump 10.13  Distrib 9.7.1, for macos26.4 (arm64)
--
-- Host: 127.0.0.1    Database: goodjob_crm
-- ------------------------------------------------------
-- Server version	9.7.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acquisition_outcome_feedback`
--

DROP TABLE IF EXISTS `acquisition_outcome_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acquisition_outcome_feedback` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `prospect_candidate_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tenant_prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `campaign_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `campaign_version` int DEFAULT '0',
  `strategy_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `run_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `provider_codes_json` json DEFAULT NULL,
  `icp_assessment_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `icp_policy_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `outcome` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) DEFAULT '0.00',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `reason_category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reason_text` text COLLATE utf8mb4_unicode_ci,
  `closed_at` datetime NOT NULL,
  `attribution_confidence` int NOT NULL,
  `attribution_reason_codes_json` json DEFAULT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_acquisition_outcome_deal` (`team_id`,`owner_id`,`deal_id`),
  KEY `idx_acquisition_outcome_scope` (`team_id`,`owner_id`,`campaign_id`,`strategy_id`,`closed_at`),
  KEY `idx_acquisition_outcome_provider` (`team_id`,`owner_id`,`outcome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_job_idempotency_aliases`
--

DROP TABLE IF EXISTS `agent_job_idempotency_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_job_idempotency_aliases` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_job_alias_idempotency` (`team_id`,`job_type`,`idempotency_key`),
  KEY `idx_agent_job_alias_job` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_jobs`
--

DROP TABLE IF EXISTS `agent_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_jobs` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `aggregate_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `parent_job_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'queued',
  `priority` int NOT NULL DEFAULT '50',
  `idempotency_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'v1',
  `input_json_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `output_json_encrypted` mediumtext COLLATE utf8mb4_unicode_ci,
  `attempt_count` int NOT NULL DEFAULT '0',
  `max_attempts` int NOT NULL DEFAULT '3',
  `next_attempt_at` datetime(3) DEFAULT NULL,
  `error_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `error_message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `trace_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` datetime(3) DEFAULT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_job_idempotency` (`team_id`,`job_type`,`idempotency_key`),
  UNIQUE KEY `uk_agent_job_execution_ref` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_agent_job_queue_bridge_ref` (`team_id`,`owner_id`,`id`,`job_type`,`parent_job_id`),
  KEY `idx_agent_job_owner_time` (`owner_id`,`created_at`),
  KEY `idx_agent_job_team_status` (`team_id`,`status`,`next_attempt_at`),
  KEY `idx_agent_job_parent` (`parent_job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ai_model_configs`
--

DROP TABLE IF EXISTS `ai_model_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_model_configs` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'openai-compatible',
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_key` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) DEFAULT '0',
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `protocol` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'openai-compatible',
  `temperature` decimal(4,2) DEFAULT '0.10',
  `use_lead_finder` tinyint(1) DEFAULT '1',
  `use_website_parse` tinyint(1) DEFAULT '1',
  `use_scoring` tinyint(1) DEFAULT '1',
  `use_email_draft` tinyint(1) DEFAULT '1',
  `use_exam` tinyint(1) DEFAULT '0',
  `last_test_at` datetime DEFAULT NULL,
  `last_test_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'untested',
  `last_test_message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_ai_model_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_studies`
--

DROP TABLE IF EXISTS `case_studies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_studies` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `story` text COLLATE utf8mb4_unicode_ci,
  `reusable_points` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_case_studies_owner` (`owner_id`),
  KEY `idx_case_studies_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_calculations`
--

DROP TABLE IF EXISTS `commission_calculations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_calculations` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month_value` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sales_amount` decimal(14,2) DEFAULT '0.00',
  `auto_commission` decimal(14,2) DEFAULT '0.00',
  `manual_adjustment` decimal(14,2) DEFAULT '0.00',
  `final_commission` decimal(14,2) DEFAULT '0.00',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `calculated_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `locked_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `locked_at` datetime DEFAULT NULL,
  `unlock_reason` text COLLATE utf8mb4_unicode_ci,
  `version_no` int DEFAULT '1',
  `is_current` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_commission_calculations_scope` (`month_value`,`owner_id`),
  KEY `idx_commission_calculations_team` (`month_value`,`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_exports`
--

DROP TABLE IF EXISTS `commission_exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_exports` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month_value` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'self',
  `scope_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `file_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'xlsx',
  `rows_count` int DEFAULT '0',
  `exported_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_commission_exports_month` (`month_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_items`
--

DROP TABLE IF EXISTS `commission_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_items` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calculation_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `product_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'auto',
  `source_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'auto',
  `rule_snapshot_json` text COLLATE utf8mb4_unicode_ci,
  `sales_amount` decimal(14,2) DEFAULT '0.00',
  `auto_amount` decimal(14,2) DEFAULT '0.00',
  `manual_amount` decimal(14,2) DEFAULT '0.00',
  `final_amount` decimal(14,2) DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_commission_items_calc` (`calculation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_products`
--

DROP TABLE IF EXISTS `commission_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_products` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `model` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `default_price` decimal(14,2) DEFAULT '0.00',
  `cost_price` decimal(14,2) DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_commission_products_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_rules`
--

DROP TABLE IF EXISTS `commission_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_rules` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(8,4) DEFAULT '0.0000',
  `fixed_amount` decimal(14,2) DEFAULT '0.00',
  `tier_json` text COLLATE utf8mb4_unicode_ci,
  `gross_profit_rate` decimal(8,4) DEFAULT '0.0000',
  `effective_from` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `effective_to` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `enabled` tinyint(1) DEFAULT '1',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_commission_rules_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `competitors`
--

DROP TABLE IF EXISTS `competitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `competitors` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `segment` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threat_level` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `strengths` text COLLATE utf8mb4_unicode_ci,
  `weaknesses` text COLLATE utf8mb4_unicode_ci,
  `competing_products` text COLLATE utf8mb4_unicode_ci,
  `our_strategy` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_competitors_owner` (`owner_id`),
  KEY `idx_competitors_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_acquisition_source_events`
--

DROP TABLE IF EXISTS `customer_acquisition_source_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_acquisition_source_events` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_source_event_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_channel` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_campaign` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `conversion_mode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processing_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_case_processing` (`team_id`,`owner_id`,`processing_key_hash`),
  UNIQUE KEY `uk_case_prospect` (`team_id`,`prospect_id`),
  UNIQUE KEY `uk_case_organization` (`team_id`,`organization_id`),
  UNIQUE KEY `uk_case_lead` (`team_id`,`owner_id`,`lead_id`),
  KEY `idx_case_customer` (`customer_id`),
  CONSTRAINT `chk_case_mode` CHECK ((`conversion_mode` in (_utf8mb4'create_new',_utf8mb4'link_existing')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_activities`
--

DROP TABLE IF EXISTS `customer_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_activities` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'note',
  `content` text COLLATE utf8mb4_unicode_ci,
  `operator_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_reminder` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_customer_activities_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_intelligence_suggestions`
--

DROP TABLE IF EXISTS `customer_intelligence_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_intelligence_suggestions` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_candidate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_event_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_label` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `suggested_fields_json` json DEFAULT NULL,
  `website` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `business` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `contact_info` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `evidence_summary` text COLLATE utf8mb4_unicode_ci,
  `evidence_refs_json` json DEFAULT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suggestion_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accepted_fields_json` json DEFAULT NULL,
  `reviewed_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_customer_intelligence_payload` (`team_id`,`owner_id`,`customer_id`,`payload_hash`),
  KEY `idx_customer_intelligence_customer` (`team_id`,`owner_id`,`customer_id`,`suggestion_status`),
  KEY `idx_customer_intelligence_candidate` (`prospect_candidate_id`),
  KEY `idx_customer_intelligence_organization` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_ownership_events`
--

DROP TABLE IF EXISTS `customer_ownership_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_ownership_events` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `event_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `operator_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_customer_ownership_customer` (`customer_id`,`created_at`),
  KEY `idx_customer_ownership_team` (`team_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stage` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(14,2) DEFAULT '0.00',
  `health` int DEFAULT '0',
  `next_reminder` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wecom_bound` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `billing_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `billing_address` text COLLATE utf8mb4_unicode_ci,
  `document_contact` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `default_port_discharge` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `default_incoterm` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `default_payment_term` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `pool_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'owned',
  `previous_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `released_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `released_at` datetime(3) DEFAULT NULL,
  `release_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `claimed_at` datetime(3) DEFAULT NULL,
  `ownership_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_customers_owner` (`owner_id`),
  KEY `idx_customers_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_report_comments`
--

DROP TABLE IF EXISTS `daily_report_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_report_comments` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci,
  `author_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_daily_report_comments_report` (`report_id`,`created_at`),
  KEY `idx_daily_report_comments_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_reports`
--

DROP TABLE IF EXISTS `daily_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_reports` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed_work` text COLLATE utf8mb4_unicode_ci,
  `customer_progress` text COLLATE utf8mb4_unicode_ci,
  `results_text` text COLLATE utf8mb4_unicode_ci,
  `risks_text` text COLLATE utf8mb4_unicode_ci,
  `next_plan` text COLLATE utf8mb4_unicode_ci,
  `support_needed` text COLLATE utf8mb4_unicode_ci,
  `report_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'submitted',
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_daily_reports_owner_date` (`owner_id`,`report_date`),
  KEY `idx_daily_reports_team_date` (`team_id`,`report_date`),
  KEY `idx_daily_reports_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deal_events`
--

DROP TABLE IF EXISTS `deal_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal_events` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `operator_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_stage` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_stage` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_action_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `related_document_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_deal_events_deal` (`deal_id`),
  KEY `idx_deal_events_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deal_recommendations`
--

DROP TABLE IF EXISTS `deal_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal_recommendations` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signal_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_candidate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `suggested_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suggested_product` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suggested_quantity` int DEFAULT '0',
  `suggested_unit_price` decimal(14,2) DEFAULT '0.00',
  `suggested_amount` decimal(14,2) DEFAULT '0.00',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `initial_stage` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '询盘',
  `next_action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_action_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `expected_close_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reason_codes_json` json DEFAULT NULL,
  `missing_fields_json` json DEFAULT NULL,
  `evidence_refs_json` json DEFAULT NULL,
  `recommendation_score` int DEFAULT '0',
  `duplicate_deal_ids_json` json DEFAULT NULL,
  `recommendation_status` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewed_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `review_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `linked_deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_deal_recommendation_signal` (`team_id`,`owner_id`,`signal_id`),
  KEY `idx_deal_recommendations_candidate` (`team_id`,`owner_id`,`prospect_candidate_id`,`recommendation_status`),
  KEY `idx_deal_recommendations_lead` (`lead_id`),
  KEY `idx_deal_recommendations_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deals`
--

DROP TABLE IF EXISTS `deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deals` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stage` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) DEFAULT '0.00',
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `archived_at` timestamp NULL DEFAULT NULL,
  `product` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `quantity` int DEFAULT '0',
  `unit_price` decimal(14,2) DEFAULT '0.00',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `amount_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'estimate',
  `next_action_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `expected_close_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `stage_changed_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `won_reason` text COLLATE utf8mb4_unicode_ci,
  `lost_reason` text COLLATE utf8mb4_unicode_ci,
  `lost_reason_category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `revisit_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exam_attempts`
--

DROP TABLE IF EXISTS `exam_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_attempts` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `passed` tinyint(1) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `answers_json` json DEFAULT NULL,
  `correct_count` int DEFAULT '0',
  `total_questions` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exam_question_links`
--

DROP TABLE IF EXISTS `exam_question_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_question_links` (
  `exam_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`exam_id`,`question_id`),
  KEY `idx_exam_question_links_exam` (`exam_id`),
  KEY `idx_exam_question_links_question` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exam_questions`
--

DROP TABLE IF EXISTS `exam_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_questions` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stem` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `options_json` json NOT NULL,
  `answer_index` int NOT NULL,
  `answer_indexes_json` json DEFAULT NULL,
  `question_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'single',
  `explanation` text COLLATE utf8mb4_unicode_ci,
  `difficulty` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `tags_json` json DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'all',
  PRIMARY KEY (`id`),
  KEY `idx_exam_questions_exam` (`exam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pass_rate` decimal(5,2) DEFAULT NULL,
  `question_count` int DEFAULT '0',
  `duration_minutes` int DEFAULT '20',
  `pass_score` int DEFAULT '80',
  `target_role` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT 'sales',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'all',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `import_export_jobs`
--

DROP TABLE IF EXISTS `import_export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_export_jobs` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rows_count` int DEFAULT '0',
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operator_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `internal_messages`
--

DROP TABLE IF EXISTS `internal_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `internal_messages` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thread_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  `subject` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci,
  `related_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `related_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_internal_messages_recipient` (`recipient_id`,`created_at`),
  KEY `idx_internal_messages_thread` (`thread_id`,`created_at`),
  KEY `idx_internal_messages_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `knowledge_assets`
--

DROP TABLE IF EXISTS `knowledge_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_assets` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'all',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lead_activities`
--

DROP TABLE IF EXISTS `lead_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_activities` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'note',
  `content` text COLLATE utf8mb4_unicode_ci,
  `operator_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_follow_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_activities_lead` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lead_source_configs`
--

DROP TABLE IF EXISTS `lead_source_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_source_configs` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'personal',
  `api_key` text COLLATE utf8mb4_unicode_ci,
  `base_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `enabled` tinyint(1) DEFAULT '0',
  `last_test_at` datetime DEFAULT NULL,
  `last_test_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'untested',
  `last_test_message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `usage_json` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_source_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lead_source_events`
--

DROP TABLE IF EXISTS `lead_source_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_source_events` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `external_id` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `occurred_at` datetime NOT NULL,
  `received_at` datetime NOT NULL,
  `raw_payload` json DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_lead_source_external` (`owner_id`,`channel`,`external_id`),
  KEY `idx_lead_source_events_lead` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `country` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `phone` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `wechat` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `intent` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '中',
  `stage` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '新线索',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estimated_amount` decimal(14,2) DEFAULT '0.00',
  `next_follow_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_activity_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `converted_customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `converted_deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'outbound',
  `source_channel` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  `source_campaign` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `external_id` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  `deleted_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deleted_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `purge_at` datetime DEFAULT NULL,
  `status_before_delete` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_leads_owner` (`owner_id`),
  KEY `idx_leads_team` (`team_id`),
  KEY `idx_leads_stage` (`stage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `market_opportunity_batches`
--

DROP TABLE IF EXISTS `market_opportunity_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_opportunity_batches` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dataset_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_version` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `empty_reason` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `candidate_count` int NOT NULL DEFAULT '0',
  `ready_count` int NOT NULL DEFAULT '0',
  `comparison_periods_json` json NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `first_trigger_job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observation_cutoff_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_market_opportunity_batch` (`team_id`,`owner_id`,`campaign_id`,`provider_id`,`dataset_fingerprint`,`policy_version`),
  KEY `idx_market_opportunity_batch_scope` (`team_id`,`owner_id`,`campaign_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `market_opportunity_calculation_events`
--

DROP TABLE IF EXISTS `market_opportunity_calculation_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_opportunity_calculation_events` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trigger_job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dataset_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_version` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `outcome` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reused_batch` tinyint(1) NOT NULL DEFAULT '0',
  `calculated_at` datetime(3) NOT NULL,
  `sequence_no` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_market_opportunity_event_job` (`trigger_job_id`),
  UNIQUE KEY `uk_market_opportunity_event_sequence` (`sequence_no`),
  KEY `idx_market_opportunity_event_scope` (`team_id`,`owner_id`,`campaign_id`,`calculated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `market_opportunity_snapshots`
--

DROP TABLE IF EXISTS `market_opportunity_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_opportunity_snapshots` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reporter_country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reporter_code` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `classification` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commodity_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commodity_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `comparison_period` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `snapshot_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insufficiency_reasons_json` json NOT NULL,
  `metrics_json` json NOT NULL,
  `market_score` decimal(10,4) DEFAULT NULL,
  `growth_score` decimal(10,4) DEFAULT NULL,
  `china_supply_score` decimal(10,4) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_market_opportunity_snapshot` (`batch_id`,`reporter_code`,`classification`,`commodity_code`),
  KEY `idx_market_opportunity_snapshot_scope` (`team_id`,`owner_id`,`campaign_id`,`batch_id`),
  KEY `idx_market_opportunity_snapshot_filter` (`batch_id`,`snapshot_status`,`classification`,`commodity_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `market_trade_observations`
--

DROP TABLE IF EXISTS `market_trade_observations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_trade_observations` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reporter_country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `partner_country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trade_flow` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commodity_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_value` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trade_value_usd` decimal(24,4) DEFAULT NULL,
  `net_weight_kg` decimal(24,6) DEFAULT NULL,
  `quantity_value` decimal(24,6) DEFAULT NULL,
  `quantity_unit` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `is_aggregate` tinyint(1) NOT NULL DEFAULT '0',
  `suppressed` tinyint(1) NOT NULL DEFAULT '0',
  `status_flags_json` json NOT NULL,
  `raw_record_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adapter_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observed_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `reporter_code` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `partner_code` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `commodity_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_revision` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_market_trade_observation` (`team_id`,`owner_id`,`campaign_id`,`provider_id`,`reporter_country`,`partner_country`,`trade_flow`,`classification`,`commodity_code`,`period_value`),
  KEY `idx_market_trade_team_campaign` (`team_id`,`campaign_id`,`observed_at`),
  KEY `idx_market_trade_owner_campaign` (`owner_id`,`campaign_id`,`observed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `memos`
--

DROP TABLE IF EXISTS `memos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memos` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinned` tinyint(1) DEFAULT '0',
  `archived` tinyint(1) DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_memos_owner` (`owner_id`),
  KEY `idx_memos_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `monthly_sales_records`
--

DROP TABLE IF EXISTS `monthly_sales_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_sales_records` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month_value` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `customer_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `product_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `quantity` decimal(14,2) DEFAULT '0.00',
  `unit_price` decimal(14,2) DEFAULT '0.00',
  `sales_amount` decimal(14,2) DEFAULT '0.00',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `exchange_rate` decimal(14,4) DEFAULT '1.0000',
  `settlement_amount` decimal(14,2) DEFAULT '0.00',
  `deal_archived_at` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `edited` tinyint(1) DEFAULT '0',
  `edit_note` text COLLATE utf8mb4_unicode_ci,
  `last_edited_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_edited_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `exchange_rate_date` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `exchange_rate_source` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `settlement_currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'CNY',
  `basis_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'deal_amount',
  `basis_date` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_monthly_sales_scope` (`month_value`,`owner_id`),
  KEY `idx_monthly_sales_team` (`month_value`,`team_id`),
  KEY `idx_monthly_sales_deal` (`deal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ocr_jobs`
--

DROP TABLE IF EXISTS `ocr_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ocr_jobs` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confidence` decimal(5,2) DEFAULT NULL,
  `fields_json` json DEFAULT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_accepted_identifiers`
--

DROP TABLE IF EXISTS `organization_accepted_identifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_accepted_identifiers` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheme` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jurisdiction` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_value_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_value_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_claim_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_raw_record_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authority_profile_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authority_profile_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_identifier_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_oi_identifier_lookup` (`team_id`,`kind`,`scheme`,`jurisdiction`,`normalized_value_hash`),
  KEY `fk_oi_identifier_organization` (`team_id`,`organization_id`),
  KEY `fk_oi_identifier_claim` (`team_id`,`source_owner_id`,`source_claim_id`),
  KEY `fk_oi_identifier_raw` (`team_id`,`source_owner_id`,`source_raw_record_id`),
  CONSTRAINT `fk_oi_identifier_claim` FOREIGN KEY (`team_id`, `source_owner_id`, `source_claim_id`) REFERENCES `organization_identity_claims` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_identifier_organization` FOREIGN KEY (`team_id`, `organization_id`) REFERENCES `organizations` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_identifier_raw` FOREIGN KEY (`team_id`, `source_owner_id`, `source_raw_record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_identifier_status` CHECK ((`status` = _utf8mb4'active'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_alias_facts`
--

DROP TABLE IF EXISTS `organization_alias_facts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_alias_facts` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias_name` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_alias` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `jurisdiction` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `source_label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_reference` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `evidence_summary` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verification_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observed_at` datetime(3) NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fact_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fact_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_organization_alias_fact_key` (`team_id`,`fact_key_hash`),
  KEY `idx_organization_alias_profile` (`team_id`,`organization_id`,`observed_at`),
  KEY `idx_organization_alias_lookup` (`team_id`,`normalized_alias`),
  KEY `fk_organization_alias_organization` (`organization_id`),
  CONSTRAINT `fk_organization_alias_organization` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_organization_alias_type` CHECK ((`alias_type` in (_utf8mb4'legal_name',_utf8mb4'trading_name',_utf8mb4'brand',_utf8mb4'previous_name',_utf8mb4'localized_name'))),
  CONSTRAINT `chk_organization_alias_verification` CHECK ((`verification_status` in (_utf8mb4'reported',_utf8mb4'verified')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_canonical_mappings`
--

DROP TABLE IF EXISTS `organization_canonical_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_canonical_mappings` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conflict_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canonical_organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mapping_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_organization_canonical_source` (`team_id`,`source_organization_id`),
  KEY `idx_organization_canonical_target` (`team_id`,`canonical_organization_id`),
  KEY `idx_organization_canonical_conflict` (`conflict_id`),
  KEY `fk_organization_canonical_source` (`source_organization_id`),
  KEY `fk_organization_canonical_target` (`canonical_organization_id`),
  CONSTRAINT `fk_organization_canonical_conflict` FOREIGN KEY (`conflict_id`) REFERENCES `organization_identity_conflicts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_organization_canonical_source` FOREIGN KEY (`source_organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_organization_canonical_target` FOREIGN KEY (`canonical_organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_organization_canonical_distinct` CHECK ((`source_organization_id` <> `canonical_organization_id`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_authority_profiles`
--

DROP TABLE IF EXISTS `organization_identity_authority_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_authority_profiles` (
  `profile_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canonical_json` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`profile_code`,`profile_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_claims`
--

DROP TABLE IF EXISTS `organization_identity_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_claims` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_record_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinal` int NOT NULL,
  `kind` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_value_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_value_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheme` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jurisdiction` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_ref_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalizer_version` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `validator_version` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authority_profile_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observed_at` datetime(3) NOT NULL,
  `claim_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `claim_fact_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_claim_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_oi_claim_resolution_ordinal` (`team_id`,`owner_id`,`resolution_id`,`ordinal`),
  KEY `fk_oi_claim_raw` (`team_id`,`owner_id`,`raw_record_id`),
  CONSTRAINT `fk_oi_claim_raw` FOREIGN KEY (`team_id`, `owner_id`, `raw_record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_claim_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_claim_ordinal` CHECK ((`ordinal` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_conflict_keys`
--

DROP TABLE IF EXISTS `organization_identity_conflict_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_conflict_keys` (
  `conflict_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinal` int NOT NULL,
  `key_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier_key_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`team_id`,`owner_id`,`conflict_id`,`ordinal`),
  CONSTRAINT `fk_oi_conflict_key_conflict` FOREIGN KEY (`team_id`, `owner_id`, `conflict_id`) REFERENCES `organization_identity_conflicts` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_conflict_key_ordinal` CHECK ((`ordinal` >= 1)),
  CONSTRAINT `chk_oi_conflict_key_type` CHECK ((`key_type` in (_utf8mb4'identifier_exact',_utf8mb4'identifier_slot',_utf8mb4'raw_binding')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_conflict_organizations`
--

DROP TABLE IF EXISTS `organization_identity_conflict_organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_conflict_organizations` (
  `conflict_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinal` int NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_role` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`team_id`,`owner_id`,`conflict_id`,`ordinal`),
  KEY `fk_oi_conflict_organization_organization` (`team_id`,`organization_id`),
  CONSTRAINT `fk_oi_conflict_organization_conflict` FOREIGN KEY (`team_id`, `owner_id`, `conflict_id`) REFERENCES `organization_identity_conflicts` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_conflict_organization_organization` FOREIGN KEY (`team_id`, `organization_id`) REFERENCES `organizations` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_conflict_organization_ordinal` CHECK ((`ordinal` >= 1)),
  CONSTRAINT `chk_oi_conflict_organization_role` CHECK ((`relation_role` in (_utf8mb4'identifier_match',_utf8mb4'existing_binding')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_conflict_reviews`
--

DROP TABLE IF EXISTS `organization_identity_conflict_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_conflict_reviews` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conflict_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canonical_organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewed_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_conflict_review_conflict` (`conflict_id`),
  KEY `idx_oi_conflict_review_team_created` (`team_id`,`created_at`),
  CONSTRAINT `fk_oi_conflict_review_conflict` FOREIGN KEY (`conflict_id`) REFERENCES `organization_identity_conflicts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_conflict_review_action` CHECK ((`action` in (_utf8mb4'keep_separate',_utf8mb4'merge'))),
  CONSTRAINT `chk_oi_conflict_review_canonical` CHECK ((((`action` = _utf8mb4'keep_separate') and (`canonical_organization_id` = _utf8mb4'')) or ((`action` = _utf8mb4'merge') and (`canonical_organization_id` <> _utf8mb4''))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_conflicts`
--

DROP TABLE IF EXISTS `organization_identity_conflicts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_conflicts` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_record_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conflict_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conflict_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_conflict_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_oi_conflict_resolution` (`team_id`,`owner_id`,`resolution_id`),
  KEY `fk_oi_conflict_raw` (`team_id`,`owner_id`,`raw_record_id`),
  CONSTRAINT `fk_oi_conflict_raw` FOREIGN KEY (`team_id`, `owner_id`, `raw_record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_conflict_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_conflict_status` CHECK ((`status` = _utf8mb4'open'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_contract_metadata`
--

DROP TABLE IF EXISTS `organization_identity_contract_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_contract_metadata` (
  `id` tinyint NOT NULL,
  `resolver_contract_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `persistence_schema_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canonical_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash_algorithm` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryption_algorithm` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `envelope_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hkdf_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deterministic_id_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_fingerprints_json` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_key_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `metadata_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_oi_metadata_singleton` CHECK ((`id` = 1)),
  CONSTRAINT `chk_oi_metadata_status` CHECK ((`status` = _utf8mb4'active'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_events`
--

DROP TABLE IF EXISTS `organization_identity_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_events` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence_no` int NOT NULL,
  `event_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_event_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_event_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_oi_event_resolution_sequence` (`team_id`,`owner_id`,`resolution_id`,`sequence_no`),
  CONSTRAINT `fk_oi_event_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_event_sequence` CHECK ((`sequence_no` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_resolution_bindings`
--

DROP TABLE IF EXISTS `organization_identity_resolution_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_resolution_bindings` (
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinal` int NOT NULL,
  `binding_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_role` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`team_id`,`owner_id`,`resolution_id`,`ordinal`),
  UNIQUE KEY `uk_oi_resolution_binding_role` (`team_id`,`owner_id`,`resolution_id`,`binding_id`,`relation_role`),
  KEY `fk_oi_resolution_binding_binding` (`team_id`,`owner_id`,`binding_id`),
  CONSTRAINT `fk_oi_resolution_binding_binding` FOREIGN KEY (`team_id`, `owner_id`, `binding_id`) REFERENCES `organization_source_bindings` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_resolution_binding_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_resolution_binding_ordinal` CHECK ((`ordinal` >= 1)),
  CONSTRAINT `chk_oi_resolution_binding_role` CHECK ((`relation_role` in (_utf8mb4'reused_existing',_utf8mb4'created_new')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_resolution_identifiers`
--

DROP TABLE IF EXISTS `organization_identity_resolution_identifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_resolution_identifiers` (
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinal` int NOT NULL,
  `identifier_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_role` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`team_id`,`owner_id`,`resolution_id`,`ordinal`),
  UNIQUE KEY `uk_oi_resolution_identifier_role` (`team_id`,`owner_id`,`resolution_id`,`identifier_id`,`relation_role`),
  KEY `fk_oi_resolution_identifier_identifier` (`team_id`,`identifier_id`),
  CONSTRAINT `fk_oi_resolution_identifier_identifier` FOREIGN KEY (`team_id`, `identifier_id`) REFERENCES `organization_accepted_identifiers` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_resolution_identifier_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_resolution_identifier_ordinal` CHECK ((`ordinal` >= 1)),
  CONSTRAINT `chk_oi_resolution_identifier_role` CHECK ((`relation_role` in (_utf8mb4'matched_existing',_utf8mb4'accepted_existing',_utf8mb4'accepted_new')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_resolutions`
--

DROP TABLE IF EXISTS `organization_identity_resolutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_resolutions` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_record_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_artifact_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processing_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `claim_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolver_contract_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parser_version` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalizer_version` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authority_profile_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authority_profile_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authority_profile_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `decision_reason_code` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conflict_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_count` int NOT NULL,
  `event_tail_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolution_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_resolution_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_oi_resolution_processing` (`team_id`,`owner_id`,`processing_key_hash`),
  KEY `fk_oi_resolution_raw` (`team_id`,`owner_id`,`raw_record_id`),
  CONSTRAINT `fk_oi_resolution_raw` FOREIGN KEY (`team_id`, `owner_id`, `raw_record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_resolution_events` CHECK ((`event_count` >= 1)),
  CONSTRAINT `chk_oi_resolution_result` CHECK ((`result` in (_utf8mb4'new_entity',_utf8mb4'exact_match',_utf8mb4'insufficient_identity',_utf8mb4'conflict')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_identity_team_guards`
--

DROP TABLE IF EXISTS `organization_identity_team_guards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_identity_team_guards` (
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_version` bigint NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`team_id`),
  CONSTRAINT `chk_oi_team_guard_version` CHECK ((`guard_version` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_relation_facts`
--

DROP TABLE IF EXISTS `organization_relation_facts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_relation_facts` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relation_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_reference` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `evidence_summary` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verification_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observed_at` datetime(3) NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fact_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fact_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_organization_relation_fact_key` (`team_id`,`fact_key_hash`),
  KEY `idx_organization_relation_source` (`team_id`,`source_organization_id`,`relation_type`),
  KEY `idx_organization_relation_target` (`team_id`,`target_organization_id`,`relation_type`),
  KEY `fk_organization_relation_source` (`source_organization_id`),
  KEY `fk_organization_relation_target` (`target_organization_id`),
  CONSTRAINT `fk_organization_relation_source` FOREIGN KEY (`source_organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_organization_relation_target` FOREIGN KEY (`target_organization_id`) REFERENCES `organizations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_organization_relation_distinct` CHECK ((`source_organization_id` <> `target_organization_id`)),
  CONSTRAINT `chk_organization_relation_type` CHECK ((`relation_type` in (_utf8mb4'direct_parent',_utf8mb4'ultimate_parent',_utf8mb4'branch_of',_utf8mb4'brand_of',_utf8mb4'affiliate'))),
  CONSTRAINT `chk_organization_relation_verification` CHECK ((`verification_status` in (_utf8mb4'reported',_utf8mb4'verified')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organization_source_bindings`
--

DROP TABLE IF EXISTS `organization_source_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_source_bindings` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_record_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_binding_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_oi_binding_active_raw` (`team_id`,`owner_id`,`raw_record_id`,`status`),
  KEY `fk_oi_binding_organization` (`team_id`,`organization_id`),
  KEY `fk_oi_binding_resolution` (`team_id`,`owner_id`,`resolution_id`),
  CONSTRAINT `fk_oi_binding_organization` FOREIGN KEY (`team_id`, `organization_id`) REFERENCES `organizations` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_binding_raw` FOREIGN KEY (`team_id`, `owner_id`, `raw_record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_binding_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_oi_binding_status` CHECK ((`status` = _utf8mb4'active'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legal_name_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_name_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oi_organization_team_id` (`team_id`,`id`),
  CONSTRAINT `chk_oi_organization_scope` CHECK (((`scope_type` = _utf8mb4'team') and (`scope_id` = `team_id`))),
  CONSTRAINT `chk_oi_organization_status` CHECK ((`status` = _utf8mb4'active'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plan_tasks`
--

DROP TABLE IF EXISTS `plan_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_tasks` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'planned',
  `due_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `completion_result` text COLLATE utf8mb4_unicode_ci,
  `completed_at` datetime DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `cancelled_at` datetime DEFAULT NULL,
  `rescheduled_from` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `rescheduled_at` datetime DEFAULT NULL,
  `reschedule_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_plan_tasks_owner` (`owner_id`),
  KEY `idx_plan_tasks_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plan_templates`
--

DROP TABLE IF EXISTS `plan_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_templates` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `output_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge_tone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phase` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int DEFAULT '0',
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_plan_templates_owner` (`owner_id`),
  KEY `idx_plan_templates_section` (`section_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `problems`
--

DROP TABLE IF EXISTS `problems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `problems` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `severity` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_customer` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `root_cause` text COLLATE utf8mb4_unicode_ci,
  `solution` text COLLATE utf8mb4_unicode_ci,
  `next_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_problems_owner` (`owner_id`),
  KEY `idx_problems_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `procurement_signals`
--

DROP TABLE IF EXISTS `procurement_signals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `procurement_signals` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_candidate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_touchpoint_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `evidence_types_json` json DEFAULT NULL,
  `evidence_summary` text COLLATE utf8mb4_unicode_ci,
  `product` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `specification` text COLLATE utf8mb4_unicode_ci,
  `quantity` int DEFAULT '0',
  `quantity_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'unknown',
  `target_price` decimal(14,2) DEFAULT '0.00',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `price_basis` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `delivery_requirement` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `certification_requirement` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `purchase_timeline` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `project_name` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `buyer_role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `confidence` int DEFAULT '0',
  `signal_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observed_at` datetime NOT NULL,
  `valid_until` datetime NOT NULL,
  `dismissed_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_procurement_signal_touchpoint` (`team_id`,`owner_id`,`prospect_candidate_id`,`source_touchpoint_id`),
  KEY `idx_procurement_signals_candidate` (`team_id`,`owner_id`,`prospect_candidate_id`,`observed_at`),
  KEY `idx_procurement_signals_lead` (`lead_id`),
  KEY `idx_procurement_signals_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_campaign_events`
--

DROP TABLE IF EXISTS `prospect_campaign_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_campaign_events` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from_version` int NOT NULL DEFAULT '0',
  `to_version` int NOT NULL DEFAULT '0',
  `revision_no` int NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prospect_campaign_event_time` (`team_id`,`campaign_id`,`created_at`),
  CONSTRAINT `fk_prospect_campaign_event_campaign` FOREIGN KEY (`team_id`, `campaign_id`) REFERENCES `prospect_campaigns` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_campaign_event_revision` CHECK ((`revision_no` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_campaign_versions`
--

DROP TABLE IF EXISTS `prospect_campaign_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_campaign_versions` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_no` int NOT NULL,
  `snapshot_json` json NOT NULL,
  `content_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_summary` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_campaign_version` (`team_id`,`campaign_id`,`version_no`),
  KEY `idx_prospect_campaign_version_time` (`team_id`,`campaign_id`,`created_at`),
  CONSTRAINT `fk_prospect_campaign_version_campaign` FOREIGN KEY (`team_id`, `campaign_id`) REFERENCES `prospect_campaigns` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_campaign_version_no` CHECK ((`version_no` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_campaigns`
--

DROP TABLE IF EXISTS `prospect_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_campaigns` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_version` int NOT NULL,
  `revision_no` int NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `archived_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_campaign_team_id` (`team_id`,`id`),
  KEY `idx_prospect_campaign_owner_status` (`team_id`,`owner_id`,`status`),
  KEY `idx_prospect_campaign_updated` (`team_id`,`updated_at`),
  CONSTRAINT `chk_prospect_campaign_status` CHECK ((`status` in (_utf8mb4'draft',_utf8mb4'active',_utf8mb4'paused',_utf8mb4'completed',_utf8mb4'archived'))),
  CONSTRAINT `chk_prospect_campaign_versions` CHECK (((`current_version` >= 1) and (`revision_no` >= 1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_candidate_processing`
--

DROP TABLE IF EXISTS `prospect_candidate_processing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_candidate_processing` (
  `hit_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processing_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failure_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `candidate_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processed_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`hit_id`),
  UNIQUE KEY `uk_pcp_team_owner_hit` (`team_id`,`owner_id`,`hit_id`),
  KEY `idx_pcp_scope_status` (`team_id`,`owner_id`,`processing_status`,`processed_at`),
  CONSTRAINT `fk_pcp_raw_hit` FOREIGN KEY (`team_id`, `owner_id`, `hit_id`) REFERENCES `prospect_source_raw_hits` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_pcp_status` CHECK ((`processing_status` in (_utf8mb4'completed',_utf8mb4'rejected')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_coverage_contract_metadata`
--

DROP TABLE IF EXISTS `prospect_coverage_contract_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_coverage_contract_metadata` (
  `id` tinyint NOT NULL,
  `contract_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `persistence_schema_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canonical_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash_algorithm` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hkdf_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `metadata_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_pc_metadata_singleton` CHECK ((`id` = 1)),
  CONSTRAINT `chk_pc_metadata_status` CHECK ((`status` = _utf8mb4'active'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_coverage_events`
--

DROP TABLE IF EXISTS `prospect_coverage_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_coverage_events` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolution_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_record_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_hit_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `strategy_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sequence_no` bigint NOT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disposition_action` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_action` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processing_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_evidence_key_hashes_json` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_source_key_hashes_json` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `evidence_snapshot_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_snapshot_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_event_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pc_event_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_pc_event_processing` (`team_id`,`processing_key_hash`),
  UNIQUE KEY `uk_pc_event_prospect_sequence` (`team_id`,`prospect_id`,`sequence_no`),
  KEY `fk_pc_event_organization` (`team_id`,`organization_id`),
  KEY `fk_pc_event_resolution` (`team_id`,`owner_id`,`resolution_id`),
  KEY `fk_pc_event_raw` (`team_id`,`owner_id`,`raw_record_id`),
  KEY `fk_pc_event_hit` (`team_id`,`owner_id`,`source_hit_id`),
  CONSTRAINT `fk_pc_event_hit` FOREIGN KEY (`team_id`, `owner_id`, `source_hit_id`) REFERENCES `prospect_source_raw_hits` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pc_event_organization` FOREIGN KEY (`team_id`, `organization_id`) REFERENCES `organizations` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pc_event_prospect` FOREIGN KEY (`team_id`, `prospect_id`) REFERENCES `tenant_prospects` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pc_event_raw` FOREIGN KEY (`team_id`, `owner_id`, `raw_record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pc_event_resolution` FOREIGN KEY (`team_id`, `owner_id`, `resolution_id`) REFERENCES `organization_identity_resolutions` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_pc_event_queue_action` CHECK ((`queue_action` in (_utf8mb4'enqueue',_utf8mb4'suppress',_utf8mb4'none'))),
  CONSTRAINT `chk_pc_event_sequence` CHECK ((`sequence_no` >= 1)),
  CONSTRAINT `chk_pc_event_type` CHECK ((`event_type` in (_utf8mb4'coverage_classified',_utf8mb4'disposition_changed')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_coverage_team_guards`
--

DROP TABLE IF EXISTS `prospect_coverage_team_guards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_coverage_team_guards` (
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_version` bigint NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`team_id`),
  CONSTRAINT `chk_pc_guard_version` CHECK ((`guard_version` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_execution_attempts`
--

DROP TABLE IF EXISTS `prospect_execution_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_execution_attempts` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lease_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkpoint_no` int NOT NULL,
  `checkpoint_call_no` int NOT NULL,
  `provider_attempt_no` int NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `response_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `error_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `error_message` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `retryable` tinyint(1) NOT NULL DEFAULT '0',
  `retry_after_at` datetime(3) DEFAULT NULL,
  `usage_json` json DEFAULT NULL,
  `cost_kind` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost_amount` decimal(18,6) DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `started_at` datetime(3) DEFAULT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `version_no` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_execution_attempt_lease` (`team_id`,`lease_id`),
  UNIQUE KEY `uk_prospect_execution_attempt_id` (`team_id`,`id`),
  KEY `fk_prospect_execution_attempt_shard` (`team_id`,`run_id`,`shard_id`),
  KEY `fk_prospect_execution_attempt_job` (`team_id`,`owner_id`,`job_id`),
  CONSTRAINT `fk_prospect_execution_attempt_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_execution_attempt_lease` FOREIGN KEY (`team_id`, `lease_id`) REFERENCES `prospect_execution_leases` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_execution_attempt_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_execution_attempt_cost` CHECK (((`cost_kind` in (_utf8mb4'actual',_utf8mb4'estimated',_utf8mb4'unknown')) and ((`cost_amount` is null) or (`cost_amount` >= 0)))),
  CONSTRAINT `chk_prospect_execution_attempt_counts` CHECK (((`checkpoint_no` >= 1) and (`checkpoint_call_no` between 0 and 3) and (`provider_attempt_no` >= 0) and (`version_no` >= 1))),
  CONSTRAINT `chk_prospect_execution_attempt_status` CHECK ((`status` in (_utf8mb4'claimed',_utf8mb4'request_started',_utf8mb4'succeeded',_utf8mb4'failed',_utf8mb4'request_outcome_unknown',_utf8mb4'cancelled_late')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_execution_checkpoints`
--

DROP TABLE IF EXISTS `prospect_execution_checkpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_execution_checkpoints` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_epoch` bigint NOT NULL,
  `checkpoint_no` int NOT NULL,
  `encrypted_cursor` mediumtext COLLATE utf8mb4_unicode_ci,
  `cursor_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `page_sequence` int NOT NULL DEFAULT '0',
  `total_call_count` int NOT NULL DEFAULT '0',
  `checkpoint_call_count` int NOT NULL DEFAULT '0',
  `accepted_count` int NOT NULL DEFAULT '0',
  `raw_count` int NOT NULL DEFAULT '0',
  `invalid_count` int NOT NULL DEFAULT '0',
  `duplicate_count` int NOT NULL DEFAULT '0',
  `retry_after_at` datetime(3) DEFAULT NULL,
  `last_error_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_error_message` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `partial` tinyint(1) NOT NULL DEFAULT '0',
  `completion_reason` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version_no` bigint NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_execution_checkpoint_shard` (`team_id`,`run_id`,`shard_id`),
  UNIQUE KEY `uk_prospect_execution_checkpoint_id` (`team_id`,`id`),
  KEY `fk_prospect_execution_checkpoint_job` (`team_id`,`owner_id`,`job_id`),
  CONSTRAINT `fk_prospect_execution_checkpoint_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_execution_checkpoint_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_execution_checkpoint_counts` CHECK (((`run_epoch` >= 1) and (`checkpoint_no` >= 1) and (`page_sequence` >= 0) and (`total_call_count` >= 0) and (`checkpoint_call_count` between 0 and 3) and (`accepted_count` >= 0) and (`raw_count` >= 0) and (`invalid_count` >= 0) and (`duplicate_count` >= 0) and (`version_no` >= 1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_execution_events`
--

DROP TABLE IF EXISTS `prospect_execution_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_execution_events` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `event_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kernel_epoch` bigint NOT NULL,
  `run_epoch` bigint NOT NULL,
  `fence_token` bigint NOT NULL,
  `detail_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prospect_execution_event_run` (`team_id`,`run_id`,`created_at`,`id`),
  CONSTRAINT `fk_prospect_execution_event_run` FOREIGN KEY (`team_id`, `run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_execution_event_numbers` CHECK (((`kernel_epoch` >= 1) and (`run_epoch` >= 1) and (`fence_token` >= 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_execution_leases`
--

DROP TABLE IF EXISTS `prospect_execution_leases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_execution_leases` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kernel_epoch` bigint NOT NULL,
  `run_epoch` bigint NOT NULL,
  `fence_token` bigint NOT NULL,
  `claim_token_hmac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `worker_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `claimed_at` datetime(3) NOT NULL,
  `heartbeat_at` datetime(3) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `deadline_at` datetime(3) NOT NULL,
  `request_started_at` datetime(3) DEFAULT NULL,
  `released_at` datetime(3) DEFAULT NULL,
  `release_reason` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version_no` bigint NOT NULL,
  `active_job_id` varchar(80) COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS ((case when (`status` = _utf8mb4'active') then `job_id` else NULL end)) STORED,
  `active_run_id` varchar(80) COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS ((case when (`status` = _utf8mb4'active') then `run_id` else NULL end)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_execution_lease_id` (`team_id`,`id`),
  UNIQUE KEY `uk_prospect_execution_fence` (`team_id`,`job_id`,`fence_token`),
  UNIQUE KEY `uk_prospect_execution_active_job` (`team_id`,`active_job_id`),
  UNIQUE KEY `uk_prospect_execution_active_run` (`team_id`,`active_run_id`),
  KEY `fk_prospect_execution_lease_shard` (`team_id`,`run_id`,`shard_id`),
  KEY `fk_prospect_execution_lease_job` (`team_id`,`owner_id`,`job_id`),
  CONSTRAINT `fk_prospect_execution_lease_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_execution_lease_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_execution_lease_fence` CHECK (((`kernel_epoch` >= 1) and (`run_epoch` >= 1) and (`fence_token` >= 1) and (`version_no` >= 1))),
  CONSTRAINT `chk_prospect_execution_lease_status` CHECK ((`status` in (_utf8mb4'active',_utf8mb4'released',_utf8mb4'expired')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_execution_pages`
--

DROP TABLE IF EXISTS `prospect_execution_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_execution_pages` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkpoint_no` int NOT NULL,
  `page_sequence` int NOT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accepted_count` int NOT NULL,
  `raw_count` int NOT NULL,
  `invalid_count` int NOT NULL,
  `duplicate_count` int NOT NULL,
  `partial` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_execution_page_sequence` (`team_id`,`run_id`,`shard_id`,`page_sequence`),
  UNIQUE KEY `uk_prospect_execution_page_id` (`team_id`,`id`),
  KEY `fk_prospect_execution_page_attempt` (`team_id`,`attempt_id`),
  CONSTRAINT `fk_prospect_execution_page_attempt` FOREIGN KEY (`team_id`, `attempt_id`) REFERENCES `prospect_execution_attempts` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_execution_page_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_execution_page_counts` CHECK (((`checkpoint_no` >= 1) and (`page_sequence` >= 1) and (`accepted_count` >= 0) and (`raw_count` >= 0) and (`invalid_count` >= 0) and (`duplicate_count` >= 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_execution_throttles`
--

DROP TABLE IF EXISTS `prospect_execution_throttles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_execution_throttles` (
  `id` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `available_at` datetime(3) NOT NULL,
  `version_no` bigint NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_execution_throttle_scope` (`team_id`,`provider_code`,`connection_id`),
  CONSTRAINT `chk_prospect_execution_throttle_version` CHECK ((`version_no` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_provider_request_accounting_evidence`
--

DROP TABLE IF EXISTS `prospect_provider_request_accounting_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_provider_request_accounting_evidence` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence_no` int NOT NULL,
  `provenance` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usage_json` json DEFAULT NULL,
  `cost_amount` decimal(18,6) DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `evidence_ref` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `evidence_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estimation_method_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_request_accounting_sequence` (`team_id`,`ledger_id`,`sequence_no`),
  CONSTRAINT `fk_provider_request_accounting_ledger` FOREIGN KEY (`team_id`, `ledger_id`) REFERENCES `prospect_provider_request_ledgers` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_provider_request_accounting_provenance` CHECK ((`provenance` in (_utf8mb4'unknown',_utf8mb4'estimated',_utf8mb4'provider_reported',_utf8mb4'portal_export',_utf8mb4'invoice_confirmed'))),
  CONSTRAINT `chk_provider_request_accounting_values` CHECK (((`sequence_no` >= 1) and ((`cost_amount` is null) or (`cost_amount` >= 0))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_provider_request_attempt_bindings`
--

DROP TABLE IF EXISTS `prospect_provider_request_attempt_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_provider_request_attempt_bindings` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding_no` int NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_request_binding_ledger_attempt` (`team_id`,`ledger_id`,`attempt_id`),
  UNIQUE KEY `uk_provider_request_binding_no` (`team_id`,`ledger_id`,`binding_no`),
  KEY `fk_provider_request_binding_attempt` (`team_id`,`attempt_id`),
  CONSTRAINT `fk_provider_request_binding_attempt` FOREIGN KEY (`team_id`, `attempt_id`) REFERENCES `prospect_execution_attempts` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_binding_ledger` FOREIGN KEY (`team_id`, `ledger_id`) REFERENCES `prospect_provider_request_ledgers` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_provider_request_binding_no` CHECK ((`binding_no` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_provider_request_dispatches`
--

DROP TABLE IF EXISTS `prospect_provider_request_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_provider_request_dispatches` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dispatch_no` int NOT NULL,
  `operation` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `replayed` tinyint(1) NOT NULL DEFAULT '0',
  `provider_executed` tinyint(1) NOT NULL DEFAULT '0',
  `external_request_id` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `response_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `error_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `started_at` datetime(3) NOT NULL,
  `confirmed_at` datetime(3) DEFAULT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `version_no` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_request_dispatch_id` (`team_id`,`id`),
  UNIQUE KEY `uk_provider_request_dispatch_no` (`team_id`,`ledger_id`,`dispatch_no`),
  KEY `fk_provider_request_dispatch_attempt` (`team_id`,`attempt_id`),
  CONSTRAINT `fk_provider_request_dispatch_attempt` FOREIGN KEY (`team_id`, `attempt_id`) REFERENCES `prospect_execution_attempts` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_dispatch_ledger` FOREIGN KEY (`team_id`, `ledger_id`) REFERENCES `prospect_provider_request_ledgers` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_provider_request_dispatch_numbers` CHECK (((`dispatch_no` >= 1) and (`version_no` >= 1))),
  CONSTRAINT `chk_provider_request_dispatch_operation` CHECK ((`operation` in (_utf8mb4'dispatch',_utf8mb4'query_by_idempotency_key',_utf8mb4'query_by_external_request_id'))),
  CONSTRAINT `chk_provider_request_dispatch_status` CHECK ((`status` in (_utf8mb4'started',_utf8mb4'confirmed',_utf8mb4'response_received',_utf8mb4'outcome_unknown',_utf8mb4'rejected')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_provider_request_events`
--

DROP TABLE IF EXISTS `prospect_provider_request_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_provider_request_events` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dispatch_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence_no` int NOT NULL,
  `event_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_request_event_sequence` (`team_id`,`ledger_id`,`sequence_no`),
  KEY `fk_provider_request_event_dispatch` (`team_id`,`dispatch_id`),
  KEY `fk_provider_request_event_attempt` (`team_id`,`attempt_id`),
  CONSTRAINT `fk_provider_request_event_attempt` FOREIGN KEY (`team_id`, `attempt_id`) REFERENCES `prospect_execution_attempts` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_event_dispatch` FOREIGN KEY (`team_id`, `dispatch_id`) REFERENCES `prospect_provider_request_dispatches` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_event_ledger` FOREIGN KEY (`team_id`, `ledger_id`) REFERENCES `prospect_provider_request_ledgers` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_provider_request_event_status` CHECK (((`event_type` in (_utf8mb4'prepared',_utf8mb4'dispatch_started',_utf8mb4'dispatch_confirmed',_utf8mb4'response_received',_utf8mb4'outcome_unknown',_utf8mb4'settled',_utf8mb4'cancelled_late')) and (`to_status` = `event_type`) and (`sequence_no` >= 1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_provider_request_ledgers`
--

DROP TABLE IF EXISTS `prospect_provider_request_ledgers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_provider_request_ledgers` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origin_attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkpoint_no` int NOT NULL,
  `logical_request_no` int NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_revision` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_config_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adapter_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contract_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_schema_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted_request_envelope` mediumtext COLLATE utf8mb4_unicode_ci,
  `request_evidence_ref` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_request_id` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dispatch_confirmation_ref` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `encrypted_response_envelope` mediumtext COLLATE utf8mb4_unicode_ci,
  `response_evidence_ref` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `response_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `raw_response_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `normalized_result_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `response_accounting_evidence_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `http_status` int DEFAULT NULL,
  `provider_outcome_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `settlement_kind` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `settlement_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `unknown_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `error_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `kernel_epoch_at_prepare` bigint NOT NULL,
  `run_epoch_at_prepare` bigint NOT NULL,
  `fence_token_at_prepare` bigint NOT NULL,
  `lease_id_at_prepare` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prepared_at` datetime(3) NOT NULL,
  `dispatch_started_at` datetime(3) DEFAULT NULL,
  `dispatch_confirmed_at` datetime(3) DEFAULT NULL,
  `response_received_at` datetime(3) DEFAULT NULL,
  `unknown_at` datetime(3) DEFAULT NULL,
  `settled_at` datetime(3) DEFAULT NULL,
  `cancelled_late_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) NOT NULL,
  `version_no` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_request_ledger_id` (`team_id`,`id`),
  UNIQUE KEY `uk_provider_request_ledger_key` (`team_id`,`owner_id`,`connection_id`,`endpoint_code`,`idempotency_key`),
  UNIQUE KEY `uk_provider_request_ledger_logical` (`team_id`,`run_id`,`shard_id`,`checkpoint_no`,`logical_request_no`),
  UNIQUE KEY `uk_provider_request_ledger_external` (`team_id`,`provider_code`,`connection_id`,`endpoint_code`,`external_request_id`),
  KEY `fk_provider_request_ledger_job` (`team_id`,`owner_id`,`job_id`),
  KEY `fk_provider_request_ledger_origin_attempt` (`team_id`,`origin_attempt_id`),
  KEY `fk_provider_request_ledger_prepare_lease` (`team_id`,`lease_id_at_prepare`),
  CONSTRAINT `fk_provider_request_ledger_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_ledger_origin_attempt` FOREIGN KEY (`team_id`, `origin_attempt_id`) REFERENCES `prospect_execution_attempts` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_ledger_prepare_lease` FOREIGN KEY (`team_id`, `lease_id_at_prepare`) REFERENCES `prospect_execution_leases` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_provider_request_ledger_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_provider_request_ledger_numbers` CHECK (((`checkpoint_no` >= 1) and (`logical_request_no` >= 1) and (`kernel_epoch_at_prepare` >= 1) and (`run_epoch_at_prepare` >= 1) and (`fence_token_at_prepare` >= 1) and (`version_no` >= 1) and ((`http_status` is null) or (`http_status` between 100 and 599)))),
  CONSTRAINT `chk_provider_request_ledger_status` CHECK ((`status` in (_utf8mb4'prepared',_utf8mb4'dispatch_started',_utf8mb4'dispatch_confirmed',_utf8mb4'response_received',_utf8mb4'outcome_unknown',_utf8mb4'settled',_utf8mb4'cancelled_late')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_qualification_contract_metadata`
--

DROP TABLE IF EXISTS `prospect_qualification_contract_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_qualification_contract_metadata` (
  `id` tinyint NOT NULL,
  `contract_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `persistence_schema_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `metadata_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_pq_metadata_singleton` CHECK ((`id` = 1)),
  CONSTRAINT `chk_pq_metadata_status` CHECK ((`status` = _utf8mb4'active'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_qualification_facts`
--

DROP TABLE IF EXISTS `prospect_qualification_facts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_qualification_facts` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visibility_scope` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted_payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pq_fact_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_pq_fact_idempotency` (`team_id`,`owner_id`,`record_type`,`idempotency_key_hash`),
  KEY `idx_pq_fact_owner_prospect` (`team_id`,`owner_id`,`prospect_id`,`record_type`,`created_at`),
  KEY `idx_pq_fact_organization` (`team_id`,`organization_id`,`record_type`,`created_at`),
  CONSTRAINT `chk_pq_fact_visibility` CHECK ((`visibility_scope` in (_utf8mb4'team',_utf8mb4'owner')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_qualification_team_guards`
--

DROP TABLE IF EXISTS `prospect_qualification_team_guards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_qualification_team_guards` (
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_version` bigint NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`team_id`),
  CONSTRAINT `chk_pq_guard_version` CHECK ((`guard_version` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_run_events`
--

DROP TABLE IF EXISTS `prospect_run_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_run_events` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence_no` int NOT NULL,
  `event_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_revision` int NOT NULL,
  `to_revision` int NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_run_event_sequence` (`team_id`,`run_id`,`sequence_no`),
  KEY `idx_prospect_run_event_time` (`team_id`,`run_id`,`created_at`,`id`),
  CONSTRAINT `fk_prospect_run_event_run` FOREIGN KEY (`team_id`, `run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_run_event_revision` CHECK (((`sequence_no` >= 1) and (`from_revision` >= 0) and (`to_revision` = (`from_revision` + 1)))),
  CONSTRAINT `chk_prospect_run_event_type` CHECK ((`event_type` in (_utf8mb4'created',_utf8mb4'started',_utf8mb4'pause_requested',_utf8mb4'paused',_utf8mb4'resumed',_utf8mb4'cancel_requested',_utf8mb4'cancelled',_utf8mb4'completed',_utf8mb4'failed')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_run_queue_child_bindings`
--

DROP TABLE IF EXISTS `prospect_run_queue_child_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_run_queue_child_bindings` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bridge_version` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `execution_snapshot_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_run_queue_child_shard` (`team_id`,`run_id`,`shard_id`),
  UNIQUE KEY `uk_prospect_run_queue_child_job` (`team_id`,`job_id`),
  KEY `fk_prospect_run_queue_child_parent` (`team_id`,`run_id`,`owner_id`,`parent_job_id`),
  KEY `fk_prospect_run_queue_child_job` (`team_id`,`owner_id`,`job_id`,`job_type`,`parent_job_id`),
  CONSTRAINT `fk_prospect_run_queue_child_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`, `job_type`, `parent_job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`, `job_type`, `parent_job_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_run_queue_child_parent` FOREIGN KEY (`team_id`, `run_id`, `owner_id`, `parent_job_id`) REFERENCES `prospect_run_queue_parent_bindings` (`team_id`, `run_id`, `owner_id`, `job_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_run_queue_child_run` FOREIGN KEY (`team_id`, `run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_run_queue_child_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_run_queue_child_contract` CHECK (((`job_type` = _utf8mb4'prospect.provider.fetch') and (`parent_job_id` <> _utf8mb4'') and (`bridge_version` = _utf8mb4'v1')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_run_queue_parent_bindings`
--

DROP TABLE IF EXISTS `prospect_run_queue_parent_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_run_queue_parent_bindings` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `bridge_version` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `execution_snapshot_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_run_queue_parent_run` (`team_id`,`run_id`),
  UNIQUE KEY `uk_prospect_run_queue_parent_job` (`team_id`,`job_id`),
  UNIQUE KEY `uk_prospect_run_queue_parent_child_ref` (`team_id`,`run_id`,`owner_id`,`job_id`),
  KEY `fk_prospect_run_queue_parent_job` (`team_id`,`owner_id`,`job_id`,`job_type`,`parent_job_id`),
  CONSTRAINT `fk_prospect_run_queue_parent_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`, `job_type`, `parent_job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`, `job_type`, `parent_job_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_run_queue_parent_run` FOREIGN KEY (`team_id`, `run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_run_queue_parent_contract` CHECK (((`job_type` = _utf8mb4'prospect.orchestrate') and (`parent_job_id` = _utf8mb4'') and (`bridge_version` = _utf8mb4'v1')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_run_shards`
--

DROP TABLE IF EXISTS `prospect_run_shards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_run_shards` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position_no` int NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_limit` int NOT NULL,
  `result_limit` int NOT NULL,
  `budget_limit` decimal(16,4) DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `adapter_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contract_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catalog_version` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capabilities_json` json NOT NULL,
  `access_mode` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `has_cursor` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_run_shard_provider` (`team_id`,`run_id`,`provider_code`),
  UNIQUE KEY `uk_prospect_run_shard_team_run_id` (`team_id`,`run_id`,`id`),
  KEY `idx_prospect_run_shard_position` (`team_id`,`run_id`,`position_no`),
  CONSTRAINT `fk_prospect_run_shard_run` FOREIGN KEY (`team_id`, `run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_run_shard_cursor` CHECK ((`has_cursor` = false)),
  CONSTRAINT `chk_prospect_run_shard_limits` CHECK (((`position_no` >= 1) and (`page_limit` >= 1) and (`result_limit` >= 1) and ((`budget_limit` is null) or (`budget_limit` >= 0)))),
  CONSTRAINT `chk_prospect_run_shard_status` CHECK ((`status` in (_utf8mb4'queued',_utf8mb4'running',_utf8mb4'retry_scheduled',_utf8mb4'pause_requested',_utf8mb4'paused',_utf8mb4'cancel_requested',_utf8mb4'cancelled',_utf8mb4'succeeded',_utf8mb4'succeeded_empty',_utf8mb4'partial_success',_utf8mb4'failed')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_schedules`
--

DROP TABLE IF EXISTS `prospect_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_schedules` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_version` int NOT NULL,
  `strategy_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_run_at` datetime(3) NOT NULL,
  `last_run_at` datetime(3) DEFAULT NULL,
  `last_run_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_planned_at` datetime(3) DEFAULT NULL,
  `last_failure_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_failure_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `recurring_cost_approved` tinyint(1) NOT NULL DEFAULT '0',
  `revision_no` int NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_schedule_team_id` (`team_id`,`id`),
  KEY `idx_prospect_schedule_due` (`team_id`,`status`,`next_run_at`),
  KEY `idx_prospect_schedule_owner` (`team_id`,`owner_id`,`status`),
  KEY `idx_prospect_schedule_strategy` (`team_id`,`strategy_id`),
  KEY `fk_prospect_schedule_strategy` (`team_id`,`campaign_id`,`campaign_version`,`strategy_id`),
  CONSTRAINT `fk_prospect_schedule_campaign_version` FOREIGN KEY (`team_id`, `campaign_id`, `campaign_version`) REFERENCES `prospect_campaign_versions` (`team_id`, `campaign_id`, `version_no`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_schedule_strategy` FOREIGN KEY (`team_id`, `campaign_id`, `campaign_version`, `strategy_id`) REFERENCES `prospect_strategies` (`team_id`, `campaign_id`, `campaign_version`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_schedule_frequency` CHECK ((`frequency` in (_utf8mb4'daily',_utf8mb4'weekly',_utf8mb4'monthly'))),
  CONSTRAINT `chk_prospect_schedule_revision` CHECK ((`revision_no` >= 1)),
  CONSTRAINT `chk_prospect_schedule_status` CHECK ((`status` in (_utf8mb4'active',_utf8mb4'paused')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_search_runs`
--

DROP TABLE IF EXISTS `prospect_search_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_search_runs` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_version` int NOT NULL,
  `strategy_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revision_no` int NOT NULL,
  `operation_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `execution_snapshot_json` json NOT NULL,
  `execution_snapshot_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_run_id` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `paused_at` datetime(3) DEFAULT NULL,
  `cancelled_at` datetime(3) DEFAULT NULL,
  `active_team_id` varchar(64) COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS ((case when (`status` in (_utf8mb4'queued',_utf8mb4'running',_utf8mb4'pause_requested',_utf8mb4'paused',_utf8mb4'cancel_requested')) then `team_id` else NULL end)) STORED,
  `active_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS ((case when (`status` in (_utf8mb4'queued',_utf8mb4'running',_utf8mb4'pause_requested',_utf8mb4'paused',_utf8mb4'cancel_requested')) then `owner_id` else NULL end)) STORED,
  `active_query_fingerprint` char(64) COLLATE utf8mb4_unicode_ci GENERATED ALWAYS AS ((case when (`status` in (_utf8mb4'queued',_utf8mb4'running',_utf8mb4'pause_requested',_utf8mb4'paused',_utf8mb4'cancel_requested')) then `query_fingerprint` else NULL end)) STORED,
  `queue_bridge_version` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `execution_epoch` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_run_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_prospect_run_idempotency` (`team_id`,`created_by`,`operation_code`,`idempotency_key_hash`),
  UNIQUE KEY `uk_prospect_run_active_fingerprint` (`active_team_id`,`active_owner_id`,`active_query_fingerprint`),
  KEY `idx_prospect_run_campaign` (`team_id`,`campaign_id`,`campaign_version`,`created_at`),
  KEY `idx_prospect_run_strategy` (`team_id`,`strategy_id`,`created_at`),
  KEY `idx_prospect_run_owner_status` (`team_id`,`owner_id`,`status`,`created_at`),
  KEY `fk_prospect_run_strategy` (`team_id`,`campaign_id`,`campaign_version`,`strategy_id`),
  CONSTRAINT `fk_prospect_run_campaign_version` FOREIGN KEY (`team_id`, `campaign_id`, `campaign_version`) REFERENCES `prospect_campaign_versions` (`team_id`, `campaign_id`, `version_no`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_run_strategy` FOREIGN KEY (`team_id`, `campaign_id`, `campaign_version`, `strategy_id`) REFERENCES `prospect_strategies` (`team_id`, `campaign_id`, `campaign_version`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_run_operation` CHECK ((`operation_code` = _utf8mb4'create_search_run_v1')),
  CONSTRAINT `chk_prospect_run_queue_bridge_version` CHECK (((`queue_bridge_version` is null) or (`queue_bridge_version` = _utf8mb4'v1'))),
  CONSTRAINT `chk_prospect_run_revision` CHECK ((`revision_no` >= 1)),
  CONSTRAINT `chk_prospect_run_status` CHECK ((`status` in (_utf8mb4'queued',_utf8mb4'running',_utf8mb4'pause_requested',_utf8mb4'paused',_utf8mb4'cancel_requested',_utf8mb4'cancelled',_utf8mb4'succeeded',_utf8mb4'succeeded_empty',_utf8mb4'partial_success',_utf8mb4'failed')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_source_raw_batches`
--

DROP TABLE IF EXISTS `prospect_source_raw_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_source_raw_batches` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adapter_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_schema_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settlement_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_artifact_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_count` int NOT NULL,
  `license_policy` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retention_policy` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retention_days` int NOT NULL,
  `retention_until` datetime(3) NOT NULL,
  `batch_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ps_raw_batch_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_ps_raw_batch_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_ps_raw_batch_ledger` (`team_id`,`ledger_id`),
  UNIQUE KEY `uk_ps_raw_batch_page` (`team_id`,`page_id`),
  KEY `fk_ps_raw_batch_shard` (`team_id`,`run_id`,`shard_id`),
  KEY `fk_ps_raw_batch_job` (`team_id`,`owner_id`,`job_id`),
  KEY `fk_ps_raw_batch_attempt` (`team_id`,`attempt_id`),
  CONSTRAINT `fk_ps_raw_batch_attempt` FOREIGN KEY (`team_id`, `attempt_id`) REFERENCES `prospect_execution_attempts` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ps_raw_batch_job` FOREIGN KEY (`team_id`, `owner_id`, `job_id`) REFERENCES `agent_jobs` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ps_raw_batch_ledger` FOREIGN KEY (`team_id`, `ledger_id`) REFERENCES `prospect_provider_request_ledgers` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ps_raw_batch_page` FOREIGN KEY (`team_id`, `page_id`) REFERENCES `prospect_execution_pages` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ps_raw_batch_run` FOREIGN KEY (`team_id`, `run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ps_raw_batch_shard` FOREIGN KEY (`team_id`, `run_id`, `shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_ps_raw_batch_retention` CHECK (((`record_count` >= 0) and (`retention_days` between 1 and 3650) and (`retention_until` >= `created_at`))),
  CONSTRAINT `chk_ps_raw_batch_schema` CHECK ((`response_schema_version` = _utf8mb4'fake-provider-source-records-v1'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_source_raw_hits`
--

DROP TABLE IF EXISTS `prospect_source_raw_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_source_raw_hits` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempt_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinal` int NOT NULL,
  `fetched_at` datetime(3) NOT NULL,
  `hit_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ps_raw_hit_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_ps_raw_hit_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_ps_raw_hit_ordinal` (`team_id`,`batch_id`,`ordinal`),
  KEY `idx_ps_raw_hit_record` (`team_id`,`owner_id`,`record_id`),
  KEY `fk_ps_raw_hit_batch` (`team_id`,`owner_id`,`batch_id`),
  CONSTRAINT `fk_ps_raw_hit_batch` FOREIGN KEY (`team_id`, `owner_id`, `batch_id`) REFERENCES `prospect_source_raw_batches` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ps_raw_hit_record` FOREIGN KEY (`team_id`, `owner_id`, `record_id`) REFERENCES `prospect_source_raw_records` (`team_id`, `owner_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_ps_raw_hit_ordinal` CHECK ((`ordinal` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_source_raw_records`
--

DROP TABLE IF EXISTS `prospect_source_raw_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_source_raw_records` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_identity_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `artifact_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `envelope_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted_envelope` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `envelope_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_observed_at` datetime(3) NOT NULL,
  `record_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ps_raw_record_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_ps_raw_record_team_owner_id` (`team_id`,`owner_id`,`id`),
  UNIQUE KEY `uk_ps_raw_record_version` (`team_id`,`owner_id`,`provider_code`,`connection_id`,`endpoint_code`,`source_identity_hash`,`artifact_hash`),
  CONSTRAINT `chk_ps_raw_record_envelope_version` CHECK ((`envelope_version` = _utf8mb4'provider-raw-v1'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_strategies`
--

DROP TABLE IF EXISTS `prospect_strategies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_strategies` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_version` int NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revision_no` int NOT NULL,
  `query_json` json NOT NULL,
  `provider_plan_json` json NOT NULL,
  `query_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fingerprint_version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `approved_at` datetime(3) DEFAULT NULL,
  `disabled_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `disabled_at` datetime(3) DEFAULT NULL,
  `disable_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_strategy_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_prospect_strategy_run_ref` (`team_id`,`campaign_id`,`campaign_version`,`id`),
  KEY `idx_prospect_strategy_campaign_status` (`team_id`,`campaign_id`,`campaign_version`,`status`),
  KEY `idx_prospect_strategy_owner_status` (`team_id`,`owner_id`,`status`),
  KEY `idx_prospect_strategy_fingerprint` (`team_id`,`campaign_id`,`campaign_version`,`query_fingerprint`),
  CONSTRAINT `fk_prospect_strategy_campaign_version` FOREIGN KEY (`team_id`, `campaign_id`, `campaign_version`) REFERENCES `prospect_campaign_versions` (`team_id`, `campaign_id`, `version_no`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_strategy_revision` CHECK ((`revision_no` >= 1)),
  CONSTRAINT `chk_prospect_strategy_status` CHECK ((`status` in (_utf8mb4'draft',_utf8mb4'approved',_utf8mb4'disabled')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_strategy_events`
--

DROP TABLE IF EXISTS `prospect_strategy_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_strategy_events` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `strategy_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_revision` int NOT NULL,
  `to_revision` int NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prospect_strategy_event_time` (`team_id`,`strategy_id`,`created_at`),
  CONSTRAINT `fk_prospect_strategy_event_strategy` FOREIGN KEY (`team_id`, `strategy_id`) REFERENCES `prospect_strategies` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_strategy_event_revision` CHECK (((`from_revision` >= 0) and (`to_revision` >= 1)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_strategy_source_positions`
--

DROP TABLE IF EXISTS `prospect_strategy_source_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_strategy_source_positions` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_version` int NOT NULL,
  `strategy_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adapter_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contract_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catalog_version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_window_mode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_window_from` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `time_window_to` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted_cursor` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `cursor_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `source_run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_shard_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_page_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_checkpoint_no` int NOT NULL,
  `source_page_sequence` int NOT NULL,
  `version_no` bigint NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_prospect_strategy_source_position_scope` (`team_id`,`owner_id`,`identity_hash`),
  UNIQUE KEY `uk_prospect_strategy_source_position_id` (`team_id`,`id`),
  KEY `idx_prospect_strategy_source_position_strategy` (`team_id`,`owner_id`,`campaign_id`,`strategy_id`,`provider_code`),
  KEY `fk_prospect_strategy_source_position_shard` (`team_id`,`source_run_id`,`source_shard_id`),
  KEY `fk_prospect_strategy_source_position_page` (`team_id`,`source_page_id`),
  CONSTRAINT `fk_prospect_strategy_source_position_page` FOREIGN KEY (`team_id`, `source_page_id`) REFERENCES `prospect_execution_pages` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_strategy_source_position_run` FOREIGN KEY (`team_id`, `source_run_id`) REFERENCES `prospect_search_runs` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prospect_strategy_source_position_shard` FOREIGN KEY (`team_id`, `source_run_id`, `source_shard_id`) REFERENCES `prospect_run_shards` (`team_id`, `run_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_prospect_strategy_source_position_cursor` CHECK ((((`status` = _utf8mb4'continuable') and (`encrypted_cursor` <> _utf8mb4'') and (`cursor_hash` <> _utf8mb4'')) or ((`status` = _utf8mb4'exhausted') and (`encrypted_cursor` = _utf8mb4'') and (`cursor_hash` = _utf8mb4'')))),
  CONSTRAINT `chk_prospect_strategy_source_position_status` CHECK ((`status` in (_utf8mb4'continuable',_utf8mb4'exhausted'))),
  CONSTRAINT `chk_prospect_strategy_source_position_values` CHECK (((`campaign_version` >= 1) and (`source_checkpoint_no` >= 1) and (`source_page_sequence` >= 1) and (`version_no` >= 1) and (`time_window_mode` in (_utf8mb4'all',_utf8mb4'fixed'))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_strategy_suggestions`
--

DROP TABLE IF EXISTS `prospect_strategy_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_strategy_suggestions` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_version` int DEFAULT '0',
  `strategy_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suggestion_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sample_metrics_json` json DEFAULT NULL,
  `proposed_adjustments_json` json DEFAULT NULL,
  `rationale` text COLLATE utf8mb4_unicode_ci,
  `reason_codes_json` json DEFAULT NULL,
  `sample_from` datetime DEFAULT NULL,
  `sample_to` datetime DEFAULT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suggestion_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewed_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_prospect_strategy_suggestion_payload` (`team_id`,`owner_id`,`payload_hash`),
  KEY `idx_prospect_strategy_suggestion_scope` (`team_id`,`owner_id`,`suggestion_status`,`created_at`),
  KEY `idx_prospect_strategy_suggestion_strategy` (`team_id`,`owner_id`,`campaign_id`,`strategy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `prospect_touchpoints`
--

DROP TABLE IF EXISTS `prospect_touchpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospect_touchpoints` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_candidate_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `channel` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci,
  `reply_classification` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `request_id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occurred_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_prospect_touchpoint_request` (`owner_id`,`prospect_candidate_id`,`request_id`),
  KEY `idx_prospect_touchpoints_candidate` (`team_id`,`owner_id`,`prospect_candidate_id`,`occurred_at`),
  KEY `idx_prospect_touchpoints_lead` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `provider_catalog`
--

DROP TABLE IF EXISTS `provider_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_catalog` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_level` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_mode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `official_docs_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `capability_json` json NOT NULL,
  `allowed_fields_json` json NOT NULL,
  `license_policy_json` json NOT NULL,
  `default_rate_policy_json` json NOT NULL,
  `retention_policy_json` json NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.0',
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_provider_catalog_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `provider_connections`
--

DROP TABLE IF EXISTS `provider_connections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_connections` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'personal',
  `credential_ref` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuration_encrypted` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disabled',
  `quota_policy_json` json NOT NULL,
  `budget_policy_json` json NOT NULL,
  `last_health_at` datetime DEFAULT NULL,
  `last_health_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'untested',
  `last_error_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_health_message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `usage_text` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_ref` (`credential_ref`),
  UNIQUE KEY `uk_provider_connection_owner` (`provider_id`,`owner_id`),
  KEY `idx_provider_connection_team` (`team_id`),
  KEY `idx_provider_connection_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `provider_request_logs`
--

DROP TABLE IF EXISTS `provider_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_request_logs` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `run_id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_shard_id` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_status` int NOT NULL DEFAULT '0',
  `attempt` int NOT NULL DEFAULT '1',
  `quota_units` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `cost_amount` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `duration_ms` int NOT NULL DEFAULT '0',
  `response_size` bigint NOT NULL DEFAULT '0',
  `error_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `requested_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_provider_request_team_time` (`team_id`,`requested_at`),
  KEY `idx_provider_request_owner_time` (`owner_id`,`requested_at`),
  KEY `idx_provider_request_run` (`run_id`),
  KEY `idx_provider_request_provider` (`provider_id`,`requested_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `provider_response_cache`
--

DROP TABLE IF EXISTS `provider_response_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_response_cache` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_version` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_encrypted` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fetched_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `license_scope` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_response_cache` (`provider_id`,`provider_version`,`request_fingerprint`,`license_scope`),
  KEY `idx_provider_response_cache_expiry` (`status`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reminders`
--

DROP TABLE IF EXISTS `reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminders` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rule_type` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_stage` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `days_count` int DEFAULT '3',
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `enabled` tinyint(1) DEFAULT '1',
  `generated_count` int DEFAULT '0',
  `target_owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_run_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_run_at` timestamp NULL DEFAULT NULL,
  `last_matched_count` int DEFAULT '0',
  `last_created_count` int DEFAULT '0',
  `last_skipped_count` int DEFAULT '0',
  `last_failed_count` int DEFAULT '0',
  `last_error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sales_record_audits`
--

DROP TABLE IF EXISTS `sales_record_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_record_audits` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `operator_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sales_record_audits_record` (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `search_execution_kernel_state`
--

DROP TABLE IF EXISTS `search_execution_kernel_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_execution_kernel_state` (
  `id` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kernel_epoch` bigint NOT NULL,
  `instance_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_search_execution_kernel_epoch` CHECK ((`kernel_epoch` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_prospects`
--

DROP TABLE IF EXISTS `tenant_prospects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_prospects` (
  `id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lifecycle_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_classification` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_state` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_reason_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_seen_at` datetime(3) NOT NULL,
  `last_seen_at` datetime(3) NOT NULL,
  `last_material_change_at` datetime(3) NOT NULL,
  `last_queued_at` datetime(3) DEFAULT NULL,
  `last_reviewed_at` datetime(3) DEFAULT NULL,
  `next_review_at` datetime(3) DEFAULT NULL,
  `hit_count` bigint NOT NULL,
  `source_count` bigint NOT NULL,
  `evidence_count` bigint NOT NULL,
  `source_key_hashes_json` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `material_evidence_key_hashes_json` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclusion_scope` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclusion_mode` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclusion_reason_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excluded_until` datetime(3) DEFAULT NULL,
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_no` bigint NOT NULL,
  `event_count` bigint NOT NULL,
  `event_tail_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospect_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `row_mac` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pc_prospect_team_id` (`team_id`,`id`),
  UNIQUE KEY `uk_pc_prospect_team_organization` (`team_id`,`organization_id`),
  CONSTRAINT `fk_pc_prospect_organization` FOREIGN KEY (`team_id`, `organization_id`) REFERENCES `organizations` (`team_id`, `id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_pc_prospect_classification` CHECK ((`last_classification` in (_utf8mb4'net_new',_utf8mb4'new_intelligence',_utf8mb4'due_review',_utf8mb4'duplicate',_utf8mb4'excluded'))),
  CONSTRAINT `chk_pc_prospect_counts` CHECK (((`hit_count` >= 1) and (`source_count` >= 1) and (`evidence_count` >= 0) and (`version_no` >= 1) and (`event_count` >= 1))),
  CONSTRAINT `chk_pc_prospect_exclusion_mode` CHECK ((`exclusion_mode` in (_utf8mb4'none',_utf8mb4'temporary',_utf8mb4'permanent'))),
  CONSTRAINT `chk_pc_prospect_exclusion_scope` CHECK ((`exclusion_scope` in (_utf8mb4'none',_utf8mb4'organization',_utf8mb4'team'))),
  CONSTRAINT `chk_pc_prospect_queue` CHECK ((`queue_state` in (_utf8mb4'none',_utf8mb4'pending',_utf8mb4'suppressed',_utf8mb4'converted'))),
  CONSTRAINT `chk_pc_prospect_status` CHECK ((`lifecycle_status` in (_utf8mb4'active',_utf8mb4'excluded',_utf8mb4'do_not_contact',_utf8mb4'converted')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `todos`
--

DROP TABLE IF EXISTS `todos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todos` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `done` tinyint(1) DEFAULT '0',
  `impact_amount` decimal(14,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `pin_state` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sort_order` int DEFAULT '0',
  `history_at` timestamp NULL DEFAULT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reminder_rule_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `trigger_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `snoozed_from` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `snooze_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `snooze_count` int DEFAULT '0',
  `snoozed_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `completed_at` timestamp NULL DEFAULT NULL,
  `completed_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `completion_result` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `prospect_candidate_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tenant_prospect_id` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `outreach_channel` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `touchpoint_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trade_documents`
--

DROP TABLE IF EXISTS `trade_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_documents` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doc_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doc_number` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `issue_date` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyer` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyer_address` text COLLATE utf8mb4_unicode_ci,
  `buyer_contact` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_address` text COLLATE utf8mb4_unicode_ci,
  `currency` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incoterm` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_term` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_method` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port_loading` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port_discharge` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validity_date` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_info` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `template_style` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `items_json` json DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `revision` int DEFAULT '1',
  `approval_note` text COLLATE utf8mb4_unicode_ci,
  `approved_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved_by` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audits_json` json DEFAULT NULL,
  `send_records_json` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_trade_documents_owner` (`owner_id`),
  KEY `idx_trade_documents_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `outbound_email` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_sender_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_signature` text COLLATE utf8mb4_unicode_ci,
  `smtp_host` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `smtp_port` int DEFAULT '465',
  `smtp_secure` tinyint(1) DEFAULT '1',
  `smtp_user` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `smtp_password` text COLLATE utf8mb4_unicode_ci,
  `last_development_email_at` datetime DEFAULT NULL,
  `last_development_email_to` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_development_email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `auth_version` int NOT NULL DEFAULT '1',
  `report_note` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `website_opportunities`
--

DROP TABLE IF EXISTS `website_opportunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `website_opportunities` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deal_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parse_mode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'rule',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `source` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_label` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `confidence` int DEFAULT NULL,
  `last_development_email_at` datetime DEFAULT NULL,
  `last_development_email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_development_email_to` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lead_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `status_changed_at` datetime DEFAULT NULL,
  `excluded_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source_evidence_json` json DEFAULT NULL,
  `tenant_prospect_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coverage_classification` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coverage_queue_state` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coverage_reason_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_touchpoint_at` datetime DEFAULT NULL,
  `last_touchpoint_channel` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_reply_classification` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `next_follow_at` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `outreach_state` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'uncontacted',
  `invalid_contact_channels_json` json DEFAULT NULL,
  `verification_report_json` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_website_opps_owner` (`owner_id`),
  KEY `idx_website_opps_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wecom_messages`
--

DROP TABLE IF EXISTS `wecom_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wecom_messages` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `owner_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `whatsapp_bindings`
--

DROP TABLE IF EXISTS `whatsapp_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whatsapp_bindings` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wa_profile_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_message_at` datetime DEFAULT NULL,
  `unread_count` int DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `binding_mode` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  `user_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `session_data` text COLLATE utf8mb4_unicode_ci,
  `twilio_phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `connection_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'disconnected',
  `last_connected_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `idx_whatsapp_bindings_customer` (`customer_id`),
  KEY `idx_whatsapp_bindings_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `whatsapp_messages`
--

DROP TABLE IF EXISTS `whatsapp_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whatsapp_messages` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `content_translated` text COLLATE utf8mb4_unicode_ci,
  `media_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `wa_message_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_whatsapp_messages_customer` (`customer_id`),
  KEY `idx_whatsapp_messages_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'goodjob_crm'
--

--
-- Dumping routines for database 'goodjob_crm'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-16 18:34:19
-- MySQL dump 10.13  Distrib 9.7.1, for macos26.4 (arm64)
--
-- Host: 127.0.0.1    Database: goodjob_crm
-- ------------------------------------------------------
-- Server version	9.7.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `users`
--
-- WHERE:  email='admin@goodjob.com'

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('u_admin','Admin','admin@goodjob.com','scrypt$YW0GG_RdFM-DrEh6JjUt5A$ptNxHCorTAR52Sx56liQXLZEAlx6ns7t2Ek20u3Av7nGttV68G1YxYcb_HYa130vggwyeUv9aCoJzPIk4v1yKA','admin','europe','AD','active','2026-07-16 10:32:10','','Admin','GoodJob CRM Admin','',465,1,'','',NULL,'','',1,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-16 18:34:19
